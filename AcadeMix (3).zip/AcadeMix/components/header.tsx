"use client"

import { useEffect, useState } from 'react'
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function Header() {
  const [avatar, setAvatar] = useState('/placeholder.svg')

  useEffect(() => {
    // Load avatar from localStorage on mount
    const savedAvatar = localStorage.getItem('userAvatar')
    if (savedAvatar) {
      setAvatar(savedAvatar)
    }

    // Listen for avatar updates
    const handleAvatarUpdate = (event: CustomEvent<string>) => {
      setAvatar(event.detail)
    }

    window.addEventListener('avatarUpdate', handleAvatarUpdate as EventListener)

    return () => {
      window.removeEventListener('avatarUpdate', handleAvatarUpdate as EventListener)
    }
  }, [])

  return (
    <header className="border-b">
      <div className="container mx-auto px-4 py-2 flex items-center justify-between">
        <h1 className="text-xl font-bold">AcadeMix</h1>
        <Avatar>
          <AvatarImage src={avatar} />
          <AvatarFallback>U</AvatarFallback>
        </Avatar>
      </div>
    </header>
  )
}

