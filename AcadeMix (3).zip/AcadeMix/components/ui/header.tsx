"use client"

import Link from 'next/link'
import { useRouter } from 'next/router'  // Importing useRouter to access the current route
import Image from 'next/image'
import { User, Info, Home, UtensilsCrossed, MessageCircle, FileText, UserCircle } from 'lucide-react'

export function Header() {
  const router = useRouter()  // Get the current route
  
  // Helper function to check if the current link matches the active route
  const isActive = (route: string) => router.pathname === route ? 'text-white' : 'text-muted-foreground'

  return (
    <header className="bg-[#000000] border-b border-border">
      <div className="container h-14 flex items-center justify-between px-4">
        {/* Logo and Brand */}
        <div className="flex items-center space-x-4">
          <Link href="/" className="flex items-center space-x-2">
            <Image
              src="https://i.ibb.co/HBMMWTF/your-image.jpg" // Updated with the new image URL
              alt="AcadeMix Logo"
              width={40} // Adjusted size
              height={40} // Adjusted size
              className="w-10 h-10" // Adjusting className to match
            />
            <span className="font-bold text-lg bg-gradient-to-r from-blue-400 to-pink-400 bg-clip-text text-transparent">
              AcadeMix
            </span>
          </Link>
        </div>

        {/* Navigation */}
        <nav className="flex items-center space-x-6">
          <Link 
            href="/student-info" 
            className={`flex items-center space-x-1 text-sm hover:text-white transition-colors ${isActive('/student-info')}`}
          >
            <Info className="w-4 h-4" />
            <span>Student info</span>
          </Link>
          
          <Link 
            href="/canteen" 
            className={`flex items-center space-x-1 text-sm hover:text-white transition-colors ${isActive('/canteen')}`}
          >
            <UtensilsCrossed className="w-4 h-4" />
            <span>Canteen</span>
          </Link>
          
          <Link 
            href="/" 
            className={`flex items-center space-x-1 text-sm hover:text-white transition-colors ${isActive('/')}`}
          >
            <Home className="w-4 h-4" />
            <span>Home</span>
          </Link>
          
          <Link 
            href="/posts" 
            className={`flex items-center space-x-1 text-sm hover:text-white transition-colors ${isActive('/posts')}`}
          >
            <FileText className="w-4 h-4" />
            <span>Posts</span>
          </Link>
          
          <Link 
            href="/opinions" 
            className={`flex items-center space-x-1 text-sm hover:text-white transition-colors ${isActive('/opinions')}`}
          >
            <MessageCircle className="w-4 h-4" />
            <span>Opinions</span>
          </Link>
        </nav>

        {/* User Profile */}
        <div className="flex items-center">
          <Link 
            href="/profile" 
            className="w-10 h-10 rounded-full border-2 border-blue-500 flex items-center justify-center hover:bg-blue-500 transition-colors"
          >
            <UserCircle className="w-6 h-6 text-white" />
          </Link>
        </div>
      </div>
    </header>
  )
}

