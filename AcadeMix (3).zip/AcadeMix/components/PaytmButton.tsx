import { Button } from "@/components/ui/button"
import { CreditCard } from 'lucide-react'

interface PaytmButtonProps {
  orderId: string
  amount: number
  onSuccess: () => void
  onFailure: () => void
}

export function PaytmButton({ orderId, amount, onSuccess, onFailure }: PaytmButtonProps) {
  const handleClick = () => {
    // In a real implementation, this would open the Paytm payment gateway
    // For this example, we'll simulate a payment process
    setTimeout(() => {
      const success = Math.random() < 0.8; // 80% success rate
      if (success) {
        onSuccess();
      } else {
        onFailure();
      }
    }, 2000);
  };

  return (
    <Button onClick={handleClick} className="w-full bg-blue-500 text-white hover:bg-blue-600">
      <CreditCard className="mr-2 h-4 w-4" /> Pay with Paytm
    </Button>
  );
}

