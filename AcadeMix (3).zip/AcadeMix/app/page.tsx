"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Image from "next/image";
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const attendanceData = [
  { subject: "Math", percentage: 85 },
  { subject: "Science", percentage: 92 },
  { subject: "English", percentage: 78 },
  { subject: "History", percentage: 88 },
  { subject: "Computer", percentage: 95 },
];

const highlights = [
  {
    id: 1,
    title: "Campus News",
    description: "Annual Tech Fest coming up next week!",
    image: "/placeholder.svg",
  },
  {
    id: 2,
    title: "Academic Update",
    description: "Mid-semester examinations schedule released",
    image: "/placeholder.svg",
  },
  {
    id: 3,
    title: "Events",
    description: "Cultural night celebrations this weekend",
    image: "/placeholder.svg",
  },
];

export default function HomePage() {
  const [currentHighlight, setCurrentHighlight] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentHighlight((prev) => (prev + 1) % highlights.length);
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="container py-8 px-4">
      <h1 className="text-4xl font-bold mb-8">Welcome to AcadeMix</h1>

      <div className="grid gap-6">
        <div className="relative h-[300px] rounded-lg overflow-hidden">
          {highlights.map((highlight, index) => (
            <div
              key={highlight.id}
              className={`absolute inset-0 transition-opacity duration-1000 ${
                index === currentHighlight ? "opacity-100" : "opacity-0"
              }`}
            >
              <Image
                src={highlight.image}
                alt={highlight.title}
                layout="fill"
                objectFit="cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-6">
                <h2 className="text-2xl font-bold text-white">
                  {highlight.title}
                </h2>
                <p className="text-white/80">{highlight.description}</p>
              </div>
            </div>
          ))}
          <div className="absolute bottom-4 right-4 flex space-x-2">
            {/* Updated Buttons */}
            <Button
              variant="outline"
              size="icon"
              style={{
                backgroundColor: "black", // Change to "black" for black buttons
                color: "white",
              }}
              onClick={() =>
                setCurrentHighlight(
                  (prev) => (prev - 1 + highlights.length) % highlights.length
                )
              }
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              style={{
                backgroundColor: "black", // Change to "black" for black buttons
                color: "white",
              }}
              onClick={() =>
                setCurrentHighlight((prev) => (prev + 1) % highlights.length)
              }
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <Card className="bg-secondary">
          <CardHeader>
            <CardTitle>Attendance Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={attendanceData}>
                <XAxis
                  dataKey="subject"
                  stroke="#888888"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  stroke="#888888"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(value) => `${value}%`}
                />
                <Bar
                  dataKey="percentage"
                  fill="currentColor"
                  radius={[4, 4, 0, 0]}
                  className="fill-primary"
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

