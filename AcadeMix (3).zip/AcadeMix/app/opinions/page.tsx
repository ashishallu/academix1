import { useState, useRef } from 'react'
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { ImageIcon, MapPin, File, Smile, Heart, MessageSquare, Search } from 'lucide-react'
import Image from "next/image"
import Link from "next/link"
import EmojiPicker from 'emoji-picker-react'
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/components/ui/use-toast"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"

interface Post {
  id: string
  content: string
  image?: string
  author: {
    name: string
    avatar: string
  }
  likes: number
  comments: Comment[] // Nested replies
  liked: boolean
}

interface Comment {
  id: string
  author: {
    name: string
    avatar: string
  }
  content: string
  likes: number
  liked: boolean
  replies: Comment[] // Replies to comments
}

export default function OpinionsPage() {
  const [postContent, setPostContent] = useState('')
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [posts, setPosts] = useState<Post[]>([
    {
      id: "1",
      content: "Here's a thought from another user.",
      image: "https://via.placeholder.com/300",  // Example image URL
      author: { name: "John Doe", avatar: "/john-doe-avatar.png" },
      likes: 3,
      comments: [
        {
          id: "1",
          author: { name: "Jane Smith", avatar: "/jane-smith-avatar.png" },
          content: "Great post!",
          likes: 2,
          liked: false,
          replies: [
            {
              id: "1-1",
              author: { name: "John Doe", avatar: "/john-doe-avatar.png" },
              content: "Thanks, Jane!",
              likes: 1,
              liked: false,
              replies: []
            }
          ]
        }
      ],
      liked: false
    },
    {
      id: "2",
      content: "Another post here with an image.",
      image: "https://via.placeholder.com/300",  // Example image URL
      author: { name: "Alice Johnson", avatar: "/alice-johnson-avatar.png" },
      likes: 5,
      comments: [],
      liked: false
    }
  ])
  const [searchQuery, setSearchQuery] = useState('')
  const fileInputRef = useRef<HTMLInputElement>(null)
  const imageInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setSelectedImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setSelectedFile(file)
    }
  }

  const handleEmojiClick = (emojiData: any) => {
    setPostContent(prev => prev + emojiData.emoji)
  }

  const handleLocationShare = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        const { latitude, longitude } = position.coords
        const locationUrl = `https://www.google.com/maps?q=${latitude},${longitude}`
        setPostContent(prev => `${prev}\n📍 My location: ${locationUrl}`)
      })
    }
  }

  const handleLike = (postId: string) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          likes: post.liked ? post.likes - 1 : post.likes + 1,
          liked: !post.liked
        }
      }
      return post
    }))
  }

  const handleLikeComment = (postId: string, commentId: string) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        const updatedComments = post.comments.map(comment => {
          if (comment.id === commentId) {
            return {
              ...comment,
              likes: comment.liked ? comment.likes - 1 : comment.likes + 1,
              liked: !comment.liked
            }
          }
          return comment
        })
        return { ...post, comments: updatedComments }
      }
      return post
    }))
  }

  const handleReplyToComment = (postId: string, commentId: string, replyContent: string) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        const updatedComments = post.comments.map(comment => {
          if (comment.id === commentId) {
            return {
              ...comment,
              replies: [
                ...comment.replies,
                {
                  id: Date.now().toString(),
                  author: { name: 'Current User', avatar: '/placeholder.svg' },
                  content: replyContent,
                  likes: 0,
                  liked: false,
                  replies: []
                }
              ]
            }
          }
          return comment
        })
        return { ...post, comments: updatedComments }
      }
      return post
    }))
  }

  const handlePostSubmit = () => {
    if (!postContent.trim()) {
      toast({ title: "Post content cannot be empty", variant: "destructive" })
      return
    }

    const newPost: Post = {
      id: Date.now().toString(), // Generate a unique ID
      content: postContent,
      image: selectedImage || '',
      author: { name: 'Current User', avatar: '/placeholder.svg' },
      likes: 0,
      comments: [],
      liked: false
    }

    setPosts([newPost, ...posts]); // Add new post at the top
    setPostContent(''); // Clear the input
    setSelectedImage(null); // Reset selected image
    setSelectedFile(null); // Reset selected file
  }

  const filteredPosts = posts.filter(post => {
    return (
      post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.author.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.comments.some(comment => 
        comment.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        comment.author.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        comment.replies.some(reply => reply.content.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    )
  })

  return (
    <div className="container max-w-2xl mx-auto p-4 space-y-6">
      {/* Search Bar */}
      <div className="mb-6">
        <div className="relative">
          <Input
            type="text"
            placeholder="Search posts or comments..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full p-3 pl-10 rounded-md border border-gray-300 bg-gray-800 text-white"
          />
          <div className="absolute top-0 left-0 mt-3 ml-3">
            <Search className="text-gray-400" />
          </div>
        </div>
      </div>

      {/* Create Post Section */}
      <Card className="p-4 shadow-lg rounded-xl bg-gradient-to-br from-purple-700 to-indigo-600">
        <div className="flex items-start gap-4 mb-4">
          <Avatar>
            <AvatarImage src="/placeholder.svg" />
            <AvatarFallback>U</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h3 className="font-semibold text-white">Current User</h3>
            <Textarea
              placeholder="Share your thoughts..."
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              className="min-h-[80px] mb-4 text-white placeholder-gray-200 bg-transparent border-none focus:ring-2 focus:ring-blue-500 resize-none"
              style={{ overflow: 'auto' }}
            />
          </div>
        </div>

        {selectedImage && (
          <div className="relative w-full h-48 mb-4 rounded-lg overflow-hidden">
            <Image
              src={selectedImage}
              alt="Selected image"
              layout="fill"
              objectFit="cover"
              className="rounded-md"
            />
          </div>
        )}

        {selectedFile && (
          <div className="mb-4 p-2 bg-gray-100 rounded-md">
            <p className="text-sm">Attached: {selectedFile.name}</p>
          </div>
        )}

        <div className="flex items-center gap-4">
          <input
            type="file"
            accept="image/*"
            className="hidden"
            ref={imageInputRef}
            onChange={handleImageUpload}
          />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => imageInputRef.current?.click()}
            className="transition-colors duration-200 ease-in hover:text-blue-500"
          >
            <ImageIcon className="h-5 w-5 text-blue-500" />
          </Button>

          <input
            type="file"
            className="hidden"
            ref={fileInputRef}
            onChange={handleFileUpload}
          />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => fileInputRef.current?.click()}
            className="transition-colors duration-200 ease-in hover:text-blue-500"
          >
            <File className="h-5 w-5 text-blue-500" />
          </Button>

          <Popover>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="icon" className="transition-colors duration-200 ease-in hover:text-blue-500">
                <Smile className="h-5 w-5 text-blue-500" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-full p-0">
              <EmojiPicker onEmojiClick={handleEmojiClick} />
            </PopoverContent>
          </Popover>

          <Button
            variant="ghost"
            size="icon"
            onClick={handleLocationShare}
            className="transition-colors duration-200 ease-in hover:text-blue-500"
          >
            <MapPin className="h-5 w-5 text-blue-500" />
          </Button>

          <Button
            className="ml-auto bg-blue-500 text-white hover:bg-blue-600"
            onClick={handlePostSubmit}
          >
            Post
          </Button>
        </div>
      </Card>

      {/* Display Filtered Posts */}
      {filteredPosts.map(post => (
        <Card key={post.id} className="p-4 shadow-lg rounded-xl bg-gradient-to-br from-indigo-600 to-purple-500">
          <div className="flex items-start gap-4 mb-4">
            <Avatar>
              <AvatarImage src={post.author.avatar} />
              <AvatarFallback>{post.author.name[0]}</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-semibold text-white">{post.author.name}</h3>
              <p className="text-white">{post.content}</p>
            </div>
          </div>

          {/* Display Post Image */}
          {post.image && (
            <div className="relative w-full h-64 mb-4 rounded-lg overflow-hidden">
              <Image
                src={post.image}
                alt="Post image"
                layout="fill"
                objectFit="cover"
                className="rounded-md"
              />
            </div>
          )}

          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleLike(post.id)}
              className={`text-white ${post.liked ? 'text-red-500' : ''}`}
            >
              <Heart className="h-4 w-4 mr-2" />
              {post.likes}
            </Button>
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="ghost" size="sm" className="text-white">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  {post.comments.length}
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gray-800 text-white max-w-2xl p-6 rounded-lg">
                <div className="space-y-4">
                  {post.comments.map(comment => (
                    <div key={comment.id} className="flex items-start gap-2 mb-4">
                      <Avatar>
                        <AvatarImage src={comment.author.avatar} />
                        <AvatarFallback>{comment.author.name[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="text-sm font-semibold">{comment.author.name}</p>
                        <p className="text-sm">{comment.content}</p>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleLikeComment(post.id, comment.id)}
                            className={`text-white ${comment.liked ? 'text-red-500' : ''}`}
                          >
                            <Heart className="h-4 w-4 mr-2" />
                            {comment.likes}
                          </Button>
                          <Button
                            variant="link"
                            size="sm"
                            onClick={() => {
                              // Open reply input for the comment
                            }}
                            className="text-blue-400"
                          >
                            Reply
                          </Button>
                        </div>

                        {/* Display Replies */}
                        <div className="pl-6 mt-2 space-y-2">
                          {comment.replies.map(reply => (
                            <div key={reply.id} className="flex items-start gap-2">
                              <Avatar>
                                <AvatarImage src={reply.author.avatar} />
                                <AvatarFallback>{reply.author.name[0]}</AvatarFallback>
                              </Avatar>
                              <div className="flex-1">
                                <p className="text-sm font-semibold">{reply.author.name}</p>
                                <p className="text-sm">{reply.content}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </Card>
      ))}
    </div>
  )
}

