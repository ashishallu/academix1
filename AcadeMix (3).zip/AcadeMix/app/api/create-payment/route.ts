import { NextResponse } from 'next/server';
import PaytmChecksum from 'paytmchecksum';

const PAYTM_MERCHANT_KEY = process.env.PAYTM_MERCHANT_KEY!;
const PAYTM_MERCHANT_ID = process.env.PAYTM_MERCHANT_ID!;
const PAYTM_WEBSITE = process.env.NODE_ENV === 'production' ? 'DEFAULT' : 'WEBSTAGING';

export async function POST(req: Request) {
  try {
    const { amount } = await req.json();
    const orderId = 'ORDER_' + Date.now();

    const paytmParams = {
      body: {
        requestType: 'Payment',
        mid: PAYTM_MERCHANT_ID,
        websiteName: PAYTM_WEBSITE,
        orderId: orderId,
        callbackUrl: `${process.env.NEXT_PUBLIC_BASE_URL}/api/payment-callback`,
        txnAmount: {
          value: amount.toString(),
          currency: 'INR',
        },
        userInfo: {
          custId: 'CUST_001',
        },
      },
    };

    // Generate checksum
    const checksum = await PaytmChecksum.generateSignature(
      JSON.stringify(paytmParams.body),
      PAYTM_MERCHANT_KEY
    );

    // Create the response with checksum signature
    const paytmResponse = {
      ...paytmParams,
      head: {
        signature: checksum,
      },
    };

    return NextResponse.json({
      orderId,
      txnToken: paytmResponse.body.txnToken,
      mid: PAYTM_MERCHANT_ID,
    });
  } catch (error) {
    console.error('Error creating payment:', error);
    return NextResponse.json({ error: 'Failed to create payment' }, { status: 500 });
  }
}

