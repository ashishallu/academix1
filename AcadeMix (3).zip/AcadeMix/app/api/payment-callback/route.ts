import { useState } from 'react';

const PaytmPayment = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handlePayment = async () => {
    setLoading(true);
    setError(null);

    try {
      // Request payment details from the backend
      const response = await fetch('/api/create-payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ amount: 500 }), // Example amount (500 INR)
      });

      const data = await response.json();

      if (data.error) {
        setError('Error: ' + data.error);
        setLoading(false);
        return;
      }

      // Load the Paytm JS SDK and initialize payment
      const script = document.createElement('script');
      script.src = 'https://secure.paytm.in/merchantpgpui/checkoutjs/merchants/<YOUR_MERCHANT_ID>/paytm.js';
      script.onload = () => {
        const paytmConfig = {
          root: '',
          flow: 'DEFAULT',
          data: {
            orderId: data.orderId,
            txnToken: data.txnToken.body.txnToken,
            tokenType: 'TXN_TOKEN',
            amount: '500.00',
          },
          handler: {
            notifyMerchant: function (eventName: string, data: any) {
              console.log(eventName, data);
            },
          },
        };

        const paytm = new window.PaytmCheckout(paytmConfig);
        paytm.initiate();
      };

      document.body.appendChild(script);
    } catch (error) {
      setError('Payment initiation failed: ' + error);
      setLoading(false);
    }
  };

  return (
    <div>
      <h1>Paytm Payment</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <button onClick={handlePayment} disabled={loading}>
        {loading ? 'Processing Payment...' : 'Pay with Paytm'}
      </button>
    </div>
  );
};

export default PaytmPayment;

