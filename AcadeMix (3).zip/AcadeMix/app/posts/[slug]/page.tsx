"use client"

import { useParams } from 'next/navigation'
import Image from 'next/image'
import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { ChevronRight, Globe } from 'lucide-react'

interface Post {
  id: string
  title: string
  description: string
  image: string
  category: string
  type: string
}

export default function PostPage() {
  const params = useParams()
  const slug = params.slug

  // In a real app, fetch this from your API
  const post: Post = {
    id: slug as string,
    title: slug?.toString().split('-').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' '),
    description: "Sharpen your oratory skills and engage in thought-provoking debates.",
    image: "/placeholder.svg?height=400&width=600",
    category: "clubEvents",
    type: "Seminars"
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="container mx-auto px-4 py-6">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-gray-400 mb-6">
          <Link href="/posts" className="hover:text-white">
            Posts
          </Link>
          <ChevronRight className="h-4 w-4" />
          <span className="text-white">{post.title}</span>
        </div>

        {/* Hero Image */}
        <div className="relative aspect-video w-full mb-8 rounded-lg overflow-hidden">
          <Image
            src={post.image}
            alt={post.title}
            layout="fill"
            objectFit="cover"
            priority
          />
        </div>

        {/* Content */}
        <div className="space-y-6">
          <h1 className="text-4xl font-bold">{post.title}</h1>
          <p className="text-gray-400">{post.description}</p>
          
          <Button
            variant="outline"
            className="bg-blue-600 text-white hover:bg-blue-700"
          >
            <Globe className="mr-2 h-4 w-4" />
            follow us on insta
          </Button>

          <div className="flex items-center gap-4 pt-4">
            <div className="text-sm">
              <span className="text-gray-400">Category: </span>
              <span>{post.category}</span>
            </div>
            <div className="text-sm">
              <span className="text-gray-400">Type: </span>
              <span>{post.type}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

