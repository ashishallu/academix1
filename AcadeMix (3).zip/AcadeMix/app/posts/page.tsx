import { Input } from "@/components/ui/input"
import { Search } from 'lucide-react'
import Image from "next/image"
import Link from "next/link"
import { useState } from 'react';

const clubs = [
  {
    name: "Gethi",
    description: "Join us to explore your musical talents and perform at various events.",
    image: "/placeholder.svg",
  },
  {
    name: "Photography Society",
    description: "Capture the world through your lens.",
    image: "/placeholder.svg",
  },
  {
    name: "Toastmasters club",
    description: "Sharpen your oratory skills and engage in thought-provoking debates.",
    image: "/placeholder.svg",
  },
  {
    name: "U.D.C",
    description: "Express yourself through dance and showcase your talent at cultural events.",
    image: "/placeholder.svg",
  },
  {
    name: "C.C.C",
    description: "Enhance your coding skills and participate in hackathons and coding competitions.",
    image: "/placeholder.svg",
  },
  {
    name: "N.S.S",
    description: "Join us in creating awareness about environmental issues and organizing eco-friendly events.",
    image: "/placeholder.svg",
  },
  {
    name: "Chaaya",
    description: "Explore the world of cinema and participate in film screenings and discussions.",
    image: "/placeholder.svg",
  },
  {
    name: "Kreeda",
    description: "Stay active and participate in various sports tournaments and fitness workshops.",
    image: "/placeholder.svg",
  },
]

export default function PostsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [posts, setPosts] = useState(clubs); // Using clubs data for demonstration

  const filteredPosts = posts.filter(post => 
    post.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container px-4 py-6">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-white">Posts</h1>
        <div className="relative w-64">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search"
            className="pl-9 bg-gray-800 text-white placeholder-gray-400"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredPosts.map((club) => (
          <Link
            key={club.name}
            href={`/posts/${club.name.toLowerCase().replace(/\s+/g, '-')}`}
            className="group cursor-pointer"
          >
            <div className="aspect-video overflow-hidden rounded-lg bg-muted mb-2">
              <Image
                src={club.image}
                alt={club.name}
                width={400}
                height={225}
                className="object-cover transition-transform group-hover:scale-105"
              />
            </div>
            <h3 className="font-medium text-white">{club.name}</h3>
            <p className="text-sm text-muted-foreground">{club.description}</p>
          </Link>
        ))}
      </div>
    </div>
  )
}

