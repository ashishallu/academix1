"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { useState } from "react"
import { Plus, Link, BookOpen, Computer } from "lucide-react" // Importing icons

export default function StudentInfoPage() {
  const [profilePhoto, setProfilePhoto] = useState("/placeholder.svg") // Default photo
  const [studentInfo, setStudentInfo] = useState({
    name: "John Doe",
    id: "2024CS001",
    department: "Computer Science",
    year: "2nd Year",
    semester: "4th Semester",
    email: "john.doe@academix.edu",
    attendance: 85,
  })

  const attendanceData = [
    { subject: "Math", percentage: 85 },
    { subject: "Science", percentage: 92 },
    { subject: "English", percentage: 78 },
    { subject: "History", percentage: 88 },
    { subject: "Computer", percentage: 95 },
  ]

  const handleProfilePhotoChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setProfilePhoto(reader.result)
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div className="container py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <Card className="bg-secondary mb-6">
          <CardHeader className="flex flex-row items-center gap-4">
            <div className="relative">
              <Avatar className="h-20 w-20">
                <AvatarImage src={profilePhoto} />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              {/* Upload button */}
              <label htmlFor="profile-upload" className="absolute bottom-0 right-0 bg-white rounded-full p-2 shadow-lg cursor-pointer transition-all hover:bg-primary-500 hover:text-white">
                <Plus className="h-5 w-5" />
              </label>
              <input
                type="file"
                id="profile-upload"
                accept="image/*"
                onChange={handleProfilePhotoChange}
                className="hidden"
              />
            </div>
            <div>
              <CardTitle className="text-2xl">{studentInfo.name}</CardTitle>
              <p className="text-muted-foreground">{studentInfo.id}</p>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm text-muted-foreground">Department</h3>
                  <p className="text-lg">{studentInfo.department}</p>
                </div>
                <div className="flex justify-between">
                  <div>
                    <h3 className="text-sm text-muted-foreground">Year</h3>
                    <p className="text-lg">{studentInfo.year}</p>
                  </div>
                  <div>
                    <h3 className="text-sm text-muted-foreground">Semester</h3>
                    <p className="text-lg">{studentInfo.semester}</p>
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm text-muted-foreground">Email</h3>
                  <p className="text-lg">{studentInfo.email}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-secondary">
            <CardHeader>
              <CardTitle>Attendance Overview</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-500"
                  style={{ width: `${studentInfo.attendance}%` }}
                />
              </div>
              <p className="mt-2 text-center">{studentInfo.attendance}% Present</p>

              {/* Links Section */}
              <div className="mt-6 space-y-4">
                <h4 className="text-lg text-black">Important Links</h4>
                <div className="space-y-2">
                  <a
                    href="https://www.cbit.ac.in/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-primary-500 text-black py-2 px-6 rounded-lg text-center hover:bg-primary-600 transition-all block flex items-center justify-center gap-2"
                  >
                    <Link className="h-5 w-5" /> View College Website
                  </a>
                  <a
                    href="https://www.library.cbit.ac.in/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-primary-500 text-black py-2 px-6 rounded-lg text-center hover:bg-primary-600 transition-all block flex items-center justify-center gap-2"
                  >
                    <BookOpen className="h-5 w-5" /> View Library Website
                  </a>
                  <a
                    href="https://erp.cbit.org.in/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-primary-500 text-black py-2 px-6 rounded-lg text-center hover:bg-primary-600 transition-all block flex items-center justify-center gap-2"
                  >
                    <Computer className="h-5 w-5" /> View ERP Portal
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-secondary">
            <CardHeader>
              <CardTitle>Subject-wise Attendance</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={attendanceData}>
                  <XAxis
                    dataKey="subject"
                    stroke="#888888"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    stroke="#888888"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value) => `${value}%`}
                  />
                  <Bar
                    dataKey="percentage"
                    fill="currentColor"
                    radius={[4, 4, 0, 0]}
                    className="fill-primary"
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

