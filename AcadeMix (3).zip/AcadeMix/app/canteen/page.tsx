"use client";

import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { ShoppingCart, Minus, Plus, Trash2, FileText, CreditCard } from "lucide-react";
import Image from "next/image";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useToast } from "@/components/ui/use-toast";

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
}

interface FoodItem {
  id: number;
  name: string;
  price: number;
  image: string;
}

interface Order {
  id: string;
  items: CartItem[];
  total: number;
  status: string;
  timestamp: Date;
}

const foodItems: FoodItem[] = [
  { id: 1, name: "Chicken Biryani", price: 130, image: "/placeholder.svg" },
  { id: 2, name: "Chicken Chapathi", price: 100, image: "/placeholder.svg" },
  { id: 3, name: "Chicken Curry", price: 50, image: "/placeholder.svg" },
  { id: 4, name: "Chicken Paratha", price: 100, image: "/placeholder.svg" },
  { id: 5, name: "Egg Chapathi", price: 80, image: "/placeholder.svg" },
  { id: 6, name: "Gulab Jamun", price: 80, image: "/placeholder.svg" },
  { id: 7, name: "Meals", price: 50, image: "/placeholder.svg" },
  { id: 8, name: "Rajma Chawal", price: 160, image: "/placeholder.svg" },
];

export default function CanteenPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [filteredItems, setFilteredItems] = useState(foodItems);
  const [orders, setOrders] = useState<Order[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    const storedOrders = localStorage.getItem("orders");
    if (storedOrders) {
      setOrders(JSON.parse(storedOrders));
    }
  }, []);

  const addToCart = (item: FoodItem) => {
    const existingItem = cart.find(cartItem => cartItem.id === item.id);
    if (existingItem) {
      toast({
        title: "Item added in Cart",
        description: `${item.name} Item is added`,
        variant: "default",
      });
      return;
    }
    setCart(currentCart => [...currentCart, { ...item, quantity: 1 }]);
    toast({
      title: "Item Added",
      description: `${item.name} has been added to your cart.`,
      variant: "default",
    });
  };

  const removeFromCart = (id: number) => {
    setCart(currentCart => {
      const existingItem = currentCart.find(item => item.id === id);
      if (existingItem && existingItem.quantity > 1) {
        return currentCart.map(item =>
          item.id === id ? { ...item, quantity: item.quantity - 1 } : item
        );
      }
      return currentCart.filter(item => item.id !== id);
    });
  };

  const isInCart = (id: number) => cart.some(item => item.id === id);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const term = e.target.value;
    setSearchTerm(term);
    const filtered = foodItems.filter(item =>
      item.name.toLowerCase().includes(term.toLowerCase())
    );
    setFilteredItems(filtered);
  };

  const cartTotal = cart.reduce((total, item) => total + item.price * item.quantity, 0);

  const handleCheckout = async () => {
    if (cart.length > 0) {
      // Get the order ID and txnToken from your API
      try {
        const response = await fetch("/api/create-payment", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ amount: cartTotal }),
        });

        const data = await response.json();

        if (data.error) {
          toast({
            title: "Payment Error",
            description: data.error,
            variant: "destructive",
          });
          return;
        }

        const { orderId, txnToken } = data;

        // Initialize the Paytm payment gateway using the received orderId and txnToken
        loadPaytmGateway(orderId, txnToken);
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to initialize payment.",
          variant: "destructive",
        });
      }
    } else {
      toast({
        title: "Cart is empty",
        description: "Please add items to the cart before proceeding.",
        variant: "destructive",
      });
    }
  };

  const loadPaytmGateway = (orderId: string, txnToken: string) => {
    const script = document.createElement("script");
    script.src = "https://secure.paytm.in/merchantpgpui/checkoutjs/merchants/<YOUR_MERCHANT_ID>/paytm.js";
    script.onload = () => {
      const paytmConfig = {
        root: "",
        flow: "DEFAULT",
        data: {
          orderId,
          txnToken,
          tokenType: "TXN_TOKEN",
          amount: cartTotal.toString(),
        },
        handler: {
          notifyMerchant: function (eventName: string, data: any) {
            if (eventName === "PAYMENT.SUCCESS") {
              handleSuccessfulPayment(orderId);  // Once payment is successful, update order status
            } else if (eventName === "PAYMENT.FAILURE") {
              toast({
                title: "Payment Failed",
                description: "The payment process failed. Please try again.",
                variant: "destructive",
              });
            }
          },
        },
      };

      const paytm = new window.PaytmCheckout(paytmConfig);
      paytm.initiate();  // Initiate Paytm payment gateway
    };
    document.body.appendChild(script);
  };

  const handleSuccessfulPayment = (orderId: string) => {
    const newOrder: Order = {
      id: orderId,
      items: cart,
      total: cartTotal,
      status: "Order Confirmed",
      timestamp: new Date(),
    };

    const updatedOrders = [...orders, newOrder];
    setOrders(updatedOrders);
    localStorage.setItem("orders", JSON.stringify(updatedOrders));
    setCart([]);
    toast({
      title: "Order Placed",
      description: `Your order has been successfully placed. Order ID: ${orderId}`,
    });
  };

  return (
    <div className="container px-4 py-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-blue-600">Canteen</h1>
        <div className="flex gap-4">
          <Sheet>
            <SheetTrigger asChild>
              <Button className="flex items-center gap-2 bg-blue-500 text-white hover:bg-blue-600 px-4 py-2 rounded-lg">
                <FileText className="h-5 w-5" />
                <span>Your Orders</span>
              </Button>
            </SheetTrigger>
            <SheetContent className="bg-white text-black">
              <SheetHeader>
                <SheetTitle>Your Orders</SheetTitle>
              </SheetHeader>
              <div className="mt-8">
                {orders.length === 0 ? (
                  <p className="text-center text-gray-500">You haven't placed any orders yet.</p>
                ) : (
                  <div className="space-y-8">
                    {orders.map(order => (
                      <div key={order.id} className="border-t pt-4">
                        <h3 className="font-semibold mb-2">Order #{order.id}</h3>
                        {order.items.map(item => (
                          <div key={item.id} className="flex justify-between items-center mb-2">
                            <span>{item.name} x{item.quantity}</span>
                            <span>₹{item.price * item.quantity}</span>
                          </div>
                        ))}
                        <div className="font-semibold mt-2">Total: ₹{order.total}</div>
                        <div className="text-sm text-blue-600 mt-1">Status: {order.status}</div>
                        <div className="text-xs text-gray-500 mt-1">
                          {order.timestamp.toLocaleString()}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </SheetContent>
          </Sheet>
          <Sheet>
            <SheetTrigger asChild>
              <Button className="flex items-center gap-2 bg-blue-500 text-white hover:bg-blue-600 px-4 py-2 rounded-lg">
                <ShoppingCart className="h-5 w-5" />
                <span>Cart ({cart.reduce((sum, item) => sum + item.quantity, 0)})</span>
              </Button>
            </SheetTrigger>
            <SheetContent className="bg-white text-black">
              <SheetHeader>
                <SheetTitle>Your Cart</SheetTitle>
              </SheetHeader>
              <div className="mt-8">
                {cart.length === 0 ? (
                  <p className="text-center text-gray-500">Your cart is empty</p>
                ) : (
                  <div className="space-y-4">
                    {cart.map(item => (
                      <div key={item.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-black">{item.name}</p>
                          <p className="text-sm text-gray-600">₹{item.price}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => removeFromCart(item.id)}
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                          <span>{item.quantity}</span>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => addToCart(item)}
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="link"
                            className="text-red-600"
                            onClick={() =>
                              setCart(cart.filter(cartItem => cartItem.id !== item.id))
                            }
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                    <div className="mt-6 text-lg font-semibold">
                      Total: ₹{cartTotal}
                    </div>
                    <Button
                      className="mt-4 w-full bg-blue-500 text-white hover:bg-blue-600"
                      onClick={handleCheckout}
                    >
                      <CreditCard className="h-5 w-5 mr-2" />
                      Checkout
                    </Button>
                  </div>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
      <div className="mb-8">
        <Input
          type="text"
          placeholder="Search food items..."
          value={searchTerm}
          onChange={handleSearch}
          className="w-full mb-4 p-2 rounded-md border"
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {filteredItems.map(item => (
            <Card key={item.id} className="border p-4">
              <Image
                src={item.image}
                alt={item.name}
                width={200}
                height={200}
                className="rounded-md mb-4"
              />
              <CardContent>
                <h3 className="font-medium text-xl">{item.name}</h3>
                <p className="text-sm text-gray-600">₹{item.price}</p>
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full bg-blue-500 text-white"
                  onClick={() => addToCart(item)}
                  disabled={isInCart(item.id)}
                >
                  {isInCart(item.id) ? "Added" : "Add to Cart"}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

