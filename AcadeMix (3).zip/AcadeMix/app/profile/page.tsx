"use client"

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/components/ui/use-toast"

interface Profile {
  name: string
  email: string
  avatar: string
  bio: string
}

export default function ProfilePage() {
  const [profile, setProfile] = useState<Profile>({
    name: "John Doe",
    email: "john@example.com",
    avatar: "/placeholder.svg",
    bio: "Student at XYZ College"
  })
  const { toast } = useToast()

  const handleAvatarUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = async () => {
        const newAvatar = reader.result as string
        // Update profile
        setProfile(prev => ({ ...prev, avatar: newAvatar }))
        // Save to localStorage or your backend
        localStorage.setItem('userAvatar', newAvatar)
        // Update header avatar
        const event = new CustomEvent('avatarUpdate', { detail: newAvatar })
        window.dispatchEvent(event)
        
        toast({
          title: "Success",
          description: "Profile photo updated successfully",
        })
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div className="container max-w-2xl mx-auto p-4">
      <Card>
        <CardHeader className="flex flex-col items-center gap-4">
          <div className="relative">
            <Avatar className="w-32 h-32">
              <AvatarImage src={profile.avatar} />
              <AvatarFallback>{profile.name[0]}</AvatarFallback>
            </Avatar>
            <input
              type="file"
              accept="image/*"
              id="avatar-upload"
              className="hidden"
              onChange={handleAvatarUpload}
            />
            <Button
              className="absolute bottom-0 right-0"
              size="sm"
              onClick={() => document.getElementById('avatar-upload')?.click()}
            >
              Change
            </Button>
          </div>
          <h2 className="text-2xl font-bold">{profile.name}</h2>
          <p className="text-gray-500">{profile.email}</p>
        </CardHeader>
        <CardContent>
          <p>{profile.bio}</p>
        </CardContent>
      </Card>
    </div>
  )
}

